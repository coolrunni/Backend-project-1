const mysql = require("mysql2");

const connection = mysql.createConnection({
  host: "sql.freedb.tech",
  user: "freedb_arijit",
  password: "gz3UmSDXP9E3j@x",
  database: "freedb_practiceqwww"
});

connection.connect((err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("Connection established");
  }
});

module.exports = connection;
