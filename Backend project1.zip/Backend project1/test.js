// let arr = [1, 2, 3, 4, 5, 7, 8, 9];

// let mappedarr = arr.map((ele) => printele(ele));

// let filtered = arr.filter((e) => 1);
// console.log(filtered);

// let sol = arr.reduce((a, b) => a + b, 0);
// console.log(sol);

// function printele(ele) {
//   return console.log(ele);
// }

// const getRes = async () => {
//   const url = "https://jsonplaceholder.typicode.com/todos/1";
//   const response = await fetch(url);
//   const data = await response.json();
//   console.log(data);
// };

// getRes();

// const getResponse = new Promise((resolve, reject) => {
//   setTimeout(() => {
//     reject("The promise is resolved");
//   }, 1000);
// });

// getResponse
//   .then((res) => {
//     console.log("res");
//   })
//   .catch((e) => {
//     console.log("galat ho gya bc ", e);
//   });
