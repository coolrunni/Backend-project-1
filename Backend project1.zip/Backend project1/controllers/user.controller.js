const conn = require("../db/config");

const getAllUsers = (req, res) => {
  conn.query("SELECT * FROM users", (err, results) => {
    if (err) {
      res.status(500).send("Error retrieving users");
    } else {
      res.json(results);
    }
  });
};

const getUser = (req, res) => {
  console.log(req.query.user);
  conn.query(
    `SELECT * FROM users where name="${req.query.user}"`,
    (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).send("Error retrieving users");
      } else {
        res.json(result);
      }
    }
  );
};

module.exports = { getAllUsers, getUser };
