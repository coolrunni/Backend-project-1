const express = require("express");
const userRouter = require("./routes/user.routes");
const singleUserRouter = require("./routes/singleuser.routes");
const app = express();
const port = 3000;

app.use(express.json());
app.use("/users", userRouter);
app.use("/user", singleUserRouter);

app.listen(port, () => {
  console.log("listening on post 3000");
});

// app.get("/", (req, res) => {
//   res.send({ Hello: "Udit" });
// });

// app.post("/", (req, res) => {
//   let { name } = req.body;
//   res.send({ Hello: name });
//   console.log(req.body);
// });

// app.post("/calc", (req, res) => {
//   let { opr } = req.query;
//   let { a, b } = req.body;

//   res.send({ ans: getResult(a, b, opr) });
// });

// function getResult(a, b, operation) {
//   switch (operation) {
//     case "add":
//     case "sum":
//       return a + b;

//     case "sub":
//       return a - b;

//     case "mul":
//       return a * b;

//     case "div":
//       return a / b;
//   }
// }

// app.get("/calc", (req, res) => {
//   console.log(req.query);
//   let { a, b, opr } = req.query;
//   res.send({ ans: getResult(parseInt(a), parseInt(b), opr) });
// });
